public class Coke extends ColdDrink{
    @Override
    public float price() {
        return 0.50f;
    }

    @Override
    public String name() {
        return "Coke";
    }
}
