class FourWheeler implements Vehicle {
    public void printVehicle() {
        System.out.println("I am four wheeler");
    }
}