public class TwoWheeler implements Vehicle {
    public void printVehicle() {
        System.out.println("I am two wheeler");
    }
}