public interface Vehicle {
    void printVehicle();
}