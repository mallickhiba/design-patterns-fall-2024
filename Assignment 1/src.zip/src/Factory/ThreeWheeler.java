class ThreeWheeler implements Vehicle {
    public void printVehicle() {
        System.out.println("I am three wheeler");
    }
}