public class SimplePizza extends Pizza{
    
    public SimplePizza(){
        description = "Simple pizza";
    }

    public int getCost(){
        return 50;
    }

}
