class ChickenFiesta extends Pizza {

    public ChickenFiesta(){
        description = "Chicken Fiesta";
    }

    public int getCost(){
        return 200;
    }
    
}