abstract class ToppingsDecorator extends Pizza {
    public abstract String getDescription();
}