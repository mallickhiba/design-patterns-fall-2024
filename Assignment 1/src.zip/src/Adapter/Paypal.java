public class Paypal {
    public void makePayment(double amount){
System.out.println("Payment made using Paypal: " + amount);

    }
    
}
